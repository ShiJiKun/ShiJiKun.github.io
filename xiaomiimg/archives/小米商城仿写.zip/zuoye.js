"use strict"
function gouwuche(){
    var menu=document.getElementById("J_miniCartMenu");
    menu.style.height="100px";
    document.getElementById("gouwuche").style.color="red";
}
function delete_gouwuche(){
    var menu=document.getElementById("J_miniCartMenu");
    menu.style.height="0px";
    document.getElementById("gouwuche").style.color="rgb(170, 166, 166)";
}
function app(){
    document.getElementById("app").style.height="140px";
}
function delete_app(){
    document.getElementById("app").style.height="0px";
}
function sosuo(){
    document.getElementById("sosuo").style.color="white";
    document.getElementById("kuang").style.background="rgb(235, 100, 10)";
}
function delete_sosuo(){
    document.getElementById("sosuo").style.color="black";
    document.getElementById("kuang").style.background="white";
}
function shoji(){
    document.getElementById("nav-bar-list0").style.height="250px";
    document.getElementById("shoji").style.color="red";
}
function delete_shoji(){
   document.getElementById("nav-bar-list0").style.height="0px"
   document.getElementById("shoji").style.color="black";
}
function hongmi(){
    document.getElementById("nav-bar-list1").style.height="250px";
    document.getElementById("Redmi").style.color="red";
}
function delete_hongmi(){
    document.getElementById("nav-bar-list1").style.height="0px"
    document.getElementById("Redmi").style.color="black";
 }
function TV(){
    document.getElementById("nav-bar-list2").style.height="250px";
    document.getElementById("TV").style.color="red";
}
function delete_TV(){
    document.getElementById("nav-bar-list2").style.height="0px"
    document.getElementById("TV").style.color="black";
}
function laptop(){
    document.getElementById("nav-bar-list3").style.height="250px";
    document.getElementById("laptop").style.color="red";
}
function delete_laptop(){
    document.getElementById("nav-bar-list3").style.height="0px"
    document.getElementById("laptop").style.color="black";
}
function jiadian(){
    document.getElementById("nav-bar-list4").style.height="250px";
    document.getElementById("jiadian").style.color="red";
}
function delete_jiadian(){
    document.getElementById("nav-bar-list4").style.height="0px"
    document.getElementById("jiadian").style.color="black";
}
function luyouqi(){
    document.getElementById("nav-bar-list5").style.height="250px";
    document.getElementById("luyouqi").style.color="red";
}
function delete_luyouqi(){
    document.getElementById("nav-bar-list5").style.height="0px"
    document.getElementById("luyouqi").style.color="black";
}
function zhineng(){
    document.getElementById("nav-bar-list6").style.height="250px";
    document.getElementById("zhineng").style.color="red";
}
function delete_zhineng(){
    document.getElementById("nav-bar-list6").style.height="0px"
    document.getElementById("zhineng").style.color="black";
}
window.onload=function init(){
    setInterval("autochange()",3000);
}
var i=1;
function autochange(){
    changeimg();
   i++;
   if(i==6)
   {
       i=1;
   }
}
function prechange(){
    i--;
    if(i<=0)
    {
        i=5;
    }
    changeimg();
}
function nextchange(){
    i++;
    if(i==6)
    {
        i=1;
    }
    changeimg();
}
function changeimg(){
    document.getElementById("lunboimg").src="小米商城图片/轮播图/"+i+".jpg";
    if(i==2){
        document.getElementById("lunboweb").href="https://www.mi.com/miwatch/color-keith?product_id=1201800001&cfrom=search";
    }
    if(i==3){
        document.getElementById("lunboweb").href="https://www.mi.com/redmitv/98";
    }
    if(i==4){
        document.getElementById("lunboweb").href="http://www.mi.com/redminote8pro?product_id=10000180&cfrom=search";
    }
    if(i==5){
        document.getElementById("lunboweb").href="https://www.mi.com/buy/detail?product_id=11777&cfrom=search";
    }
}
function phone(){
    document.getElementById("phonecard").style.background="rgb(245, 108, 16)";
    document.getElementById("tabtanchu").style.display="block";
}
function delete_phone(){
    document.getElementById("phonecard").style.background="none";
    document.getElementById("tabtanchu").style.display="none";
}
function tvbox(){
    document.getElementById("tvbox").style.background="rgb(245, 108, 16)";
    document.getElementById("tabtanchu1").style.display="block";
}
function delete_tvbox(){
    document.getElementById("tvbox").style.background="none";
    document.getElementById("tabtanchu1").style.display="none";
}
function scree(){
    document.getElementById("screen").style.background="rgb(245, 108, 16)";
    document.getElementById("tabtanchu2").style.display="block";
}
function delete_screen(){
    document.getElementById("screen").style.background="none";
    document.getElementById("tabtanchu2").style.display="none";
}
function ban(){
    document.getElementById("ban").style.background="rgb(245, 108, 16)";
    document.getElementById("tabtanchu3").style.display="block";
}
function delete_ban(){
    document.getElementById("ban").style.background="none";
    document.getElementById("tabtanchu3").style.display="none";
}
function chuxing(){
    document.getElementById("chuxing").style.background="rgb(245, 108, 16)";
    document.getElementById("tabtanchu4").style.display="block";
}
function delete_chuxing(){
    document.getElementById("chuxing").style.background="none";
    document.getElementById("tabtanchu4").style.display="none";
}
function zhinengluyou(){
    document.getElementById("zhinengluyou").style.background="rgb(245, 108, 16)";
    document.getElementById("tabtanchu5").style.display="block";
}
function delete_zhinengluyou(){
    document.getElementById("zhinengluyou").style.background="none";
    document.getElementById("tabtanchu5").style.display="none";
}
function dianyuan(){
    document.getElementById("dianyuan").style.background="rgb(245, 108, 16)";
    document.getElementById("tabtanchu6").style.display="block";
}
function delete_dianyuan(){
    document.getElementById("dianyuan").style.background="none";
    document.getElementById("tabtanchu6").style.display="none";
}
function health(){
    document.getElementById("health").style.background="rgb(245, 108, 16)";
    document.getElementById("tabtanchu7").style.display="block";
}
function delete_health(){
    document.getElementById("health").style.background="none";
    document.getElementById("tabtanchu7").style.display="none";
}
function erji(){
    document.getElementById("erji").style.background="rgb(245, 108, 16)";
    document.getElementById("tabtanchu8").style.display="block";
}
function delete_erji(){
    document.getElementById("erji").style.background="none";
    document.getElementById("tabtanchu8").style.display="none";
}
function life(){
    document.getElementById("life").style.background="rgb(245, 108, 16)";
    document.getElementById("tabtanchu9").style.display="block";
}
function delete_life(){
    document.getElementById("life").style.background="none";
    document.getElementById("tabtanchu9").style.display="none";
}
function pre(){
    document.getElementById("pre").style.background="rgb(0, 0, 0,0.6)";
    document.getElementById("pretu").style.color="white";
}
function delete_pre(){
    document.getElementById("pre").style.background="none";
    document.getElementById("pretu").style.color="rgb(170, 166, 166)";
}
function nex(){
    document.getElementById("nex").style.background="rgb(0, 0, 0,0.6)";
    document.getElementById("nextu").style.color="white";
}
function delete_nex(){
    document.getElementById("nex").style.background="none";
    document.getElementById("nextu").style.color="rgb(170, 166, 166)";
}
function tupian1(){
    document.getElementById("tupian1").style.boxShadow=" 5px  5px 5px rgba(0,0,0,.18)";
}
function delete_tupian1(){
    document.getElementById("tupian1").style.boxShadow="none";
}
function tupian2(){
    document.getElementById("tupian2").style.boxShadow=" 5px  5px 5px rgba(0,0,0,.18)";
}
function delete_tupian2(){
    document.getElementById("tupian2").style.boxShadow="none";
}
function tupian3(){
    document.getElementById("tupian3").style.boxShadow=" 5px  5px 5px rgba(0,0,0,.18)";
}
function delete_tupian3(){
    document.getElementById("tupian3").style.boxShadow="none";
}
function chakanquanbu(){
    document.getElementById("chakanquanbu").style.color="#ff6700";
    document.getElementById("xiangyou").style.color="#ff6700";
}
function delete_chakanquanbu(){
    document.getElementById("chakanquanbu").style.color="black";
    document.getElementById("xiangyou").style.color="gray";
}
function shangoujian(){
    document.getElementById("shangoujian").style.color="#ff6700";
}
function delete_shangoujian(){
    document.getElementById("shangoujian").style.color="rgb(170, 166, 166)";
}
function shangoujian1(){
    document.getElementById("shangoujian1").style.color="#ff6700";
}
function delete_shangoujian1(){
    document.getElementById("shangoujian1").style.color="rgb(170, 166, 166)";
}
var temp=0;
function xiangyouqiehuan(){
    var x=document.getElementById("shangoukuang2").style.left;
    if(temp==5)
    {
        return;
    }
    temp++;
    x=x.replace("px","");
    x=Number(x)-980;
    document.getElementById("shangoukuang2").style.left=x+"px";
}
function xiangzuoqiehuan(){
    var x=document.getElementById("shangoukuang2").style.left;
    x=x.replace("px","");
    if(temp==0)
    {
        return;
    }
    temp--;
    x=Number(x)+980;
    document.getElementById("shangoukuang2").style.left=x+"px";
}
function shojiAPP(){
    document.getElementById("appkuang").style.display="block";
}
function delete_shojiAPP(){
    document.getElementById("appkuang").style.display="none";
}
function openweb1(){
    window.open("https://account.xiaomi.com/pass/serviceLogin?callback=https%3A%2F%2Forder.mi.com%2Flogin%2Fcallback%3Ffollowup%3Dhttps%253A%252F%252Fwww.mi.com%252Fuser%252Fportal%26sign%3DYTIxYzlhMDk1MGIxYTIxZmQ2YWFkN2I0MjkwNjIzYWE1ZDIyNjdlOQ%2C%2C&sid=mi_eshop&_bannerBiz=mistore&_qrsize=180",'_blank');
}
function openweb2(){
    window.open("https://account.xiaomi.com/pass/serviceLogin?callback=https%3A%2F%2Fservice.order.mi.com%2Flogin%2Fcallback%3Ffollowup%3D%252F%252Fservice.order.mi.com%252Fapply%252Ffront%26sign%3DNjRkMTk5NGZkMjBkM2MzZWZjMDBmNTRlNjgwNmYyNmU4ZDViZDZhZg%2C%2C&sid=mi_eshop&_bannerBiz=mistore&_qrsize=180");
}
function openweb3(){
    window.open("https://account.xiaomi.com/pass/serviceLogin?callback=https%3A%2F%2Fservice.order.mi.com%2Flogin%2Fcallback%3Ffollowup%3D%252F%252Fservice.order.mi.com%252Fapply%252Ffront%26sign%3DNjRkMTk5NGZkMjBkM2MzZWZjMDBmNTRlNjgwNmYyNmU4ZDViZDZhZg%2C%2C&sid=mi_eshop&_bannerBiz=mistore&_qrsize=180");
}
function openweb4(){
    window.open("https://account.xiaomi.com/pass/serviceLogin?callback=https%3A%2F%2Fservice.order.mi.com%2Flogin%2Fcallback%3Ffollowup%3D%252F%252Fservice.order.mi.com%252Fapply%252Ffront%26sign%3DNjRkMTk5NGZkMjBkM2MzZWZjMDBmNTRlNjgwNmYyNmU4ZDViZDZhZg%2C%2C&sid=mi_eshop&_bannerBiz=mistore&_qrsize=180");
}






